# DM2-All-Projects-Reports

A comprehensive project management and reporting system with role-based access control.

## Features

- **Three-Portal System**: Admin, Manager, and TL & Coordinator portals
- **Real-time Data Integration**: Google Sheets and Excel file upload
- **Advanced Analytics**: Utilisation, Stack Ranking, and Team Performance calculations
- **3D Interactive UI**: Modern design with animations and visualizations
- **Feedback System**: Communication between managers and TLs/Coordinators

## Login Credentials

- **Admin**: `admin@dm2.com` / `admin123`
- **Manager**: `manager@dm2.com` / `manager123`
- **TL**: `tl@dm2.com` / `tl123`

## Data Sources

- Google Sheets integration with custom URL input
- Excel file upload (.xlsx) with automatic column mapping
- Real-time calculations with your exact formulas

## Live Demo

Visit the live application at: [Your Netlify URL will appear here]

## Technical Stack

- HTML5, CSS3, JavaScript (ES6+)
- Chart.js for data visualizations
- SheetJS for Excel parsing
- LocalStorage for data persistence
- Netlify for hosting

## Deployment

This application is deployed on Netlify with automatic builds from the main branch.
